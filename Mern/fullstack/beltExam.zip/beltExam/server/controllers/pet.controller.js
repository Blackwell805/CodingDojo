const Pet = require("../models/pet.model");

//Be sure to change properly. Replace words that are capitalized with a capitalized word. etc. 

//C
module.exports.createNewPet = (req, res) => {
  Pet.create(req.body)
    .then(newlyCreatedPet => res.json({ pet: newlyCreatedPet }))
    .catch(err => res.json({ message: "Something went wrong", error: err }));
};

//R
module.exports.findAllPets = (req, res) => {
  Pet.find()
    .then(allDaPets => res.json({ pets: allDaPets })) //The key pets is what I will put after response.data when doing API call.
    .catch(err => res.json({ message: "Something went wrong", error: err }));
};

module.exports.findOneSinglePet = (req, res) => {
	Pet.findOne({ _id: req.params.id })
		.then(oneSinglePet => res.json({ pet: oneSinglePet }))
		.catch(err => res.json({ message: "Something went wrong", error: err }));
};


//U
module.exports.updateExistingPet = (req, res) => {
  console.log('Hello!!!!')
  Pet.findOneAndUpdate({ _id: req.params.id }, req.body, { new: true })
    .then(updatedPet => res.json({ pet: updatedPet }))
    .catch(err => res.json({ message: "Something went wrong", error: err }));
};
// module.exports.updateExistingUser = (req, res) => {
//   Pet.findOneAndUpdate({ _id: req.params.id }, {$addToSet: {quotes: req.body}}, { new: true, runValidators:true })
//     .then(updatedUser => res.json({ user: updatedUser }))
//     .catch(err => res.json({ message: "Something went wrong", error: err }));
// };

//D
module.exports.deletePet = (req, res) => {
  Pet.deleteOne({ _id: req.params.id })
    .then(result => res.json({ result: result }))
    .catch(err => res.json({ message: "Something went wrong", error: err }));
};
