import React from 'react'
import { Link } from '@reach/router'

const PetList = (props) => {
    const {pets} = props;



    return (
        <div>
            <table>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Actions Available</th>
                </tr>
                </thead>
                <tbody>
                {
                    pets.map((animal, i) => 
                        <tr key={i}>
                            <td>{animal.name}</td>
                            <td>{animal.type}</td>
                            <td><Link to={`/pets/${animal._id}`}>Details</Link></td>
                            <td><Link to={`/pets/${animal._id}/edit`}>Edit</Link></td>
                        </tr>
                    )
                }
                </tbody>
            </table>
        </div>

    )
}

export default PetList
