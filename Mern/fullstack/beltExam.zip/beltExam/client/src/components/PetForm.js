import React from 'react'
import { Link} from '@reach/router';


const PetForm = (props) => {
const {name, setName, type, setType, description, setDescription, skill1, setSkill1, skill2, setSkill2, skill3, setSkill3, onSubmitHandler} = props;



    return (
        <div>
            <h1>Pet Shelter</h1>
            <h4>Know a pet needing a home?</h4>
            <Link to={'/'}>Back to Home</Link>
            <div>
                <form onSubmit={onSubmitHandler}>
                    <p>
                        <label>Pet Name:</label>
                        <input type='text' onChange={(e)=>setName(e.target.value)} value={name}/>
                    </p>
                    <p>
                        <label>Pet Type:</label>
                        <input type='text' onChange={(e)=>setType(e.target.value)} value={type}/>
                    </p>
                    <p>
                        <label>Pet Description:</label>
                        <input type='text' onChange={(e)=>setDescription(e.target.value)} value={description}/>
                    </p>
                    <p>
                        <label>Skill 1:</label>
                        <input type='text' onChange={(e)=>setSkill1(e.target.value)} value={skill1}/>
                    </p>
                    <p>
                        <label>Skill 2:</label>
                        <input type='text' onChange={(e)=>setSkill2(e.target.value)} value={skill2}/>
                    </p>
                    <p>
                        <label>Skill 3:</label>
                        <input type='text' onChange={(e)=>setSkill3(e.target.value)} value={skill3}/>
                    </p>
                    <button type='submit' ><label >Add Pet</label></button>
                </form>
            </div>

        </div>
    )
}

export default PetForm
