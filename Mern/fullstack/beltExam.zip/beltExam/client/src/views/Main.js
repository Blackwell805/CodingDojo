import React, {useState, useEffect} from 'react'
import { Link } from '@reach/router';
import PetList from '../components/PetList'
import axios from 'axios'



const Main = () => {
    const [pets, setPets] = useState([])
    // const [loaded, setLoaded] = useState(false)

useEffect(()=> {
    axios.get("http://localhost:8000/api/pets/")
    .then(response=>{setPets(response.data.pets)}) //Look to the key in the response to Json in Controllers
    .catch(err=>console.log(err))
}, []);


// if(loaded){
//     return (
//         <p>Loading....</p>
//     )
// }

    return (
        <div>
            <h1>Pet Shelter</h1>
            <h3>These pets are looking for a good home</h3>
            <Link to={'/pets/new'}>add a pet to the shelter</Link>
            <PetList pets={pets} setPets={setPets}/>
        </div>
    )
}

export default Main
