import React from 'react'
import {Link} from '@reach/router';

const PetDetails = (props) => {
    const [pets] = props;


    return (
        <div>
            <h1>Pet Shelter</h1>
            <h4>Details about: `${pets.name}`</h4>
            <Link to={'/'}>Back to Home</Link>

            <p>Pet Type: {pets.type}</p>
            <p>Description: {pets.description}</p>
            <p>Skills: {pets.skill1}, {pets.skill2}, {pets.skill3}</p>
        </div>
    )
}

export default PetDetails
