import React, {useState, useEffect} from 'react'
import axios from 'axios'
import {navigate} from '@reach/router'
import PetForm from '../components/PetForm'

const EditPet = (props) => {
    const [name, setName] = useState('')
    const [type, setType] = useState('')
    const [description, setDescription] = useState('')
    const [skill1, setSkill1] = useState('')
    const [skill2, setSkill2] = useState('')
    const [skill3, setSkill3] = useState('')

    useEffect(()=>{
        axios.get(`http://localhost:8000/api/pets/${props.id}`)
            .then(response=>{
            setName(response.data.pet.name)
            setType(response.data.pet.type)
            setDescription(response.data.pet.description)
            setSkill1(response.data.pet.skill1)
            setSkill2(response.data.pet.skill2)
            setSkill3(response.data.pet.skill3)
            })
            
    }, []);
    
    
    const onSubmitHandler = e => {
        console.log("Hello??")
        e.preventDefault();
        axios.put(`http://localhost:8000/api/pets/update/${props.id}`, {
            name,
            type,
            description,
            skill1,
            skill2,
            skill3
        })
        .then(response=>{
            console.log(response)
            setName('')
            setType('')
            setDescription('')
            setSkill1('')
            setSkill2('')
            setSkill3('')
            navigate('/')
        })
        .catch(err=>console.log('Something went wrong with the Adding a Pet!'))
    }

    return (
        <div>
            <PetForm
            name={name} setName={setName} 
            type={type} setType={setType}
            description={description} setDescription={setDescription}
            skill1={skill1} setSkill1={setSkill1}
            skill2={skill2} setSkill2={setSkill2}
            skill3={skill3} setSkill3={setSkill3}
            onSubmitHandler={onSubmitHandler}
            />
        </div>
    )
}

export default EditPet
