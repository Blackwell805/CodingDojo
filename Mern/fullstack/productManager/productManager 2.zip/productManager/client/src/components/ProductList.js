import React from 'react'
import { Link } from '@reach/router'

const ProductList = (props) => {
    return (
        <div>
            {
                props.products.map((product, i)=> {
                    const path=`/${product._id}`
                    return <p key={i}><Link to={path}>{product.title}</Link></p>
                })
            }
        </div>
    )
}

export default ProductList
