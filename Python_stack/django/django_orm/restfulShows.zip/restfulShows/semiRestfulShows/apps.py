from django.apps import AppConfig


class SemirestfulshowsConfig(AppConfig):
    name = 'semiRestfulShows'
